export MODEL_NAME="Mistral-7B-v0.2"
export CHECKPOINT="Yi-6B-2024_06_13-20_57_44/checkpoint-100"

python test.py \
--model_name_or_path "/home/qingyu_yin/model/$MODEL_NAME" \
--tokenizer "/home/qingyu_yin/model/$MODEL_NAME" \
--data_name_or_path "expression" \

python test.py \
--model_name_or_path "/home/qingyu_yin/model/$MODEL_NAME" \
--tokenizer "/home/qingyu_yin/model/$MODEL_NAME" \
--data_name_or_path "code" \


python test.py \
--model_name_or_path "/home/qingyu_yin/model/$MODEL_NAME" \
--tokenizer "/home/qingyu_yin/model/$MODEL_NAME" \
--data_name_or_path "relation" \

python test.py \
--model_name_or_path "/home/qingyu_yin/model/$MODEL_NAME" \
--tokenizer "/home/qingyu_yin/model/$MODEL_NAME" \
--data_name_or_path "bool" \ 

# python test.py --data_name_or_path "group"