export CXX=g++
export OMP_NUM_THREADS=8
export MODEL_NAME="Qwen1.5-0.5B"
torchrun --nproc_per_node=4 --master_port=12355 finetune.py \
    --model_name_or_path "/home/qingyu_yin/model/$MODEL_NAME" \
    --data_path "data/ft_data_4k.json" \
    --fp16 True \
    --output_dir "result/$MODEL_NAME" \
    --num_train_epochs 3 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 4 \
    --gradient_accumulation_steps 4 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 10 \
    --save_total_limit 100 \
    --learning_rate 1e-5 \
    --weight_decay 0. \
    --warmup_step 20 \
    --lr_scheduler_type "constant_with_warmup" \
    --logging_steps 1 \
    --deepspeed "deepspeed/zero3.json" \

export MODEL_NAME="Qwen1.5-1.8B"
torchrun --nproc_per_node=4 --master_port=12355 finetune.py \
    --model_name_or_path "/home/qingyu_yin/model/$MODEL_NAME" \
    --data_path "data/ft_data_4k.json" \
    --fp16 True \
    --output_dir "result/$MODEL_NAME" \
    --num_train_epochs 3 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 4 \
    --gradient_accumulation_steps 4 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 10 \
    --save_total_limit 100 \
    --learning_rate 1e-5 \
    --weight_decay 0. \
    --warmup_step 20 \
    --lr_scheduler_type "constant_with_warmup" \
    --logging_steps 1 \
    --deepspeed "deepspeed/zero3.json" \