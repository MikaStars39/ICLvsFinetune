#!/bin/bash
source /etc/bashrc
source /home/qingyu_yin/miniconda3/etc/profile.d/conda.sh

cd /home/qingyu_yin/project/pattern
conda activate llama

nvidia-smi

time=$(date "+%Y_%m_%d-%H_%M_%S")
export MODEL_NAME="Qwen1.5-4B"
torchrun --nproc_per_node=8 --master_port=12355 finetune.py \
    --model_name_or_path "/home/qingyu_yin/model/$MODEL_NAME-$time" \
    --data_path "data/ft_data_4k.json" \
    --fp16 True \
    --output_dir "result/$MODEL_NAME" \
    --num_train_epochs 3 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 4 \
    --gradient_accumulation_steps 4 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 10 \
    --save_total_limit 100 \
    --learning_rate 1e-5 \
    --weight_decay 0. \
    --warmup_step 20 \
    --lr_scheduler_type "constant_with_warmup" \
    --logging_steps 1 \
    --deepspeed "deepspeed/zero3.json" \
    --max_steps 300 \

time=$(date "+%Y_%m_%d-%H_%M_%S")
export MODEL_NAME="Qwen1.5-7B"
torchrun --nproc_per_node=8 --master_port=12355 finetune.py \
    --model_name_or_path "/home/qingyu_yin/model/$MODEL_NAME-$time" \
    --data_path "data/ft_data_4k.json" \
    --fp16 True \
    --output_dir "result/$MODEL_NAME" \
    --num_train_epochs 3 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 4 \
    --gradient_accumulation_steps 4 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 10 \
    --save_total_limit 100 \
    --learning_rate 1e-5 \
    --weight_decay 0. \
    --warmup_step 20 \
    --lr_scheduler_type "constant_with_warmup" \
    --logging_steps 1 \
    --deepspeed "deepspeed/zero3.json" \
    --max_steps 300 \