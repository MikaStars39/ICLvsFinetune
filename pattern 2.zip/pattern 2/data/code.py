import json

def process_file(input_filename, output_filename):
    # 读取文件内容
    with open(input_filename, 'r') as file:
        content = file.read().strip()
    
    # 按照 '@' 分割字符串
    codes = content.split('@')
    
    # 准备存储为JSON的数据
    data = []
    for code in codes:
        # 每个项目包含code, type, number
        entry = {"code": code, "type": "", "number": ""}
        
        # 查找特定字符串后的字符
        search_string = "def function2(z, a):\n    return z "
        pos = code.find(search_string)
        if pos != -1:
            # 安全地获取type和number字符
            try:
                entry["type"] = code[pos + len(search_string)]
                entry["number"] = code[pos + len(search_string) + 2]
            except IndexError:
                # 如果找不到足够的字符，保持为空
                pass
        
        data.append(entry)
    
    # 将数据写入JSON文件
    with open(output_filename, 'w') as json_file:
        json.dump(data, json_file, indent=4)

# 调用函数，传入输入和输出文件名
process_file('code.txt', 'code.json')
